<?php
	/*	
	*	Goodlayers Plugin Framework 1.0.0
	*/

	include_once(TOURMASTER_LOCAL . '/framework/function/media.php');
	include_once(TOURMASTER_LOCAL . '/framework/function/utility.php');
	include_once(TOURMASTER_LOCAL . '/framework/function/file-system.php');
	include_once(TOURMASTER_LOCAL . '/framework/function/widget-util.php');
	
	include_once(TOURMASTER_LOCAL . '/framework/function/page-option.php');
	include_once(TOURMASTER_LOCAL . '/framework/function/plugin-option.php');
	include_once(TOURMASTER_LOCAL . '/framework/function/tax-option.php');
	include_once(TOURMASTER_LOCAL . '/framework/function/html-option.php');